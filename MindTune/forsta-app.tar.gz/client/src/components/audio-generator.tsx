import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Edit, Sliders, Play, Pause, StopCircle, FileVolume, ChevronsUp, Download, Sparkles, Headphones, Upload, Mic, MicOff, Video, X, FileAudio, Square, Camera, Monitor, Palette, Settings, Film, Clapperboard, Loader2, Music } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useAudio } from "@/hooks/use-audio";
import { Link } from "wouter";
const createAudioSchema = (maxDuration: number) => z.object({
  affirmations: z.string().min(1, "Please enter your affirmations"),
  preset: z.string().optional(),
  customFrequency: z.number().min(1).max(10000),
  volume: z.number().min(0).max(100),
  duration: z.number().min(1).max(maxDuration),
  voice: z.enum(["female", "male"]),
  // Upload and recording options
  uploadedAudio: z.instanceof(File).optional(),
  uploadedVideo: z.instanceof(File).optional(),
  recordedAudio: z.instanceof(Blob).optional(),
  useUploadedAudio: z.boolean().default(false),
  useUploadedVideo: z.boolean().default(false),
  useRecordedAudio: z.boolean().default(false),
  generateVideoOutput: z.boolean().default(false),
  generateAudioOutput: z.boolean().default(true),
  // Video editing options
  textOverlayEnabled: z.boolean().default(false),
  textFont: z.string().default("Arial"),
  textFontSize: z.number().default(24),
  textColor: z.string().default("#FFFFFF"),
  textPosition: z.enum(["top", "center", "bottom", "top-left", "top-right", "bottom-left", "bottom-right"]).default("center"),
  textOpacity: z.number().min(0).max(1).default(0.8),
  textAnimation: z.enum(["none", "fade", "slide", "typewriter"]).default("fade"),
  showAffirmationsAsText: z.boolean().default(false),
  // Video creation options
  createVideoFromScratch: z.boolean().default(false),
  videoCreationType: z.enum(["canvas", "camera", "screen"]).default("canvas"),
  canvasBackground: z.string().default("#000000"),
  videoDuration: z.number().min(10).max(7200).default(60), // 2 hours for Premium users
  recordedVideo: z.instanceof(Blob).optional(),
});

type AudioFormData = z.infer<ReturnType<typeof createAudioSchema>>;

const PRESETS = [
  { value: "delta", label: "Delta Waves (1-4 Hz) - Deep Sleep", frequency: 2 },
  { value: "theta", label: "Theta Waves (4-8 Hz) - Deep Meditation", frequency: 6 },
  { value: "alpha", label: "Alpha Waves (8-13 Hz) - Relaxed Focus", frequency: 10 },
  { value: "beta", label: "Beta Waves (14-30 Hz) - Active Thinking", frequency: 20 },
  { value: "gamma", label: "Gamma Waves (30-100 Hz) - High Focus", frequency: 40 },
  { value: "high_gamma", label: "High Gamma (100-200 Hz) - Peak Performance", frequency: 150 },
  { value: "ultra_high", label: "Ultra High (200-1000 Hz) - Advanced", frequency: 500 },
  { value: "sonic", label: "Sonic Range (1-10 kHz) - Experimental", frequency: 5000 },
];

const SAMPLE_AFFIRMATIONS = [
  "I am confident and successful",
  "I attract abundance into my life", 
  "I am worthy of love and happiness",
  "I believe in my unlimited potential",
  "I am grateful for all the good in my life"
];

export default function AudioGenerator() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [characterCount, setCharacterCount] = useState(0);
  const [membershipInfo, setMembershipInfo] = useState<{
    membershipTier: string;
    downloadsUsed: number;
    canDownload: boolean;
    reason?: string;
    isOnTrial?: boolean;
  } | null>(null);
  
  // Recording states
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  
  // Preview audio management
  const [previewAudio, setPreviewAudio] = useState<HTMLAudioElement | null>(null);
  
  // Video creation and recording states
  const [isVideoRecording, setIsVideoRecording] = useState(false);
  const [videoRecorder, setVideoRecorder] = useState<MediaRecorder | null>(null);
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
  const [recordedVideoBlob, setRecordedVideoBlob] = useState<Blob | null>(null);
  const [canvasRecorder, setCanvasRecorder] = useState<MediaRecorder | null>(null);
  const [generatedVideoBlob, setGeneratedVideoBlob] = useState<Blob | null>(null);
  
  const { toast } = useToast();
  
  const {
    isPlaying,
    currentTime,
    duration: audioDuration,
    generatedAudio,
    playPreview,
    stopPreview,
    generateAudio,
    generatePreview,
    downloadAudio,
    setPreviewVolume
  } = useAudio();

  // Get maximum duration based on membership tier
  const getMaxDuration = () => {
    if (!membershipInfo) return 1; // Default to free tier if no membership info
    
    switch (membershipInfo.membershipTier) {
      case 'premium':
        return 120; // 2 hours
      case 'basic':
        return 30; // 30 minutes
      case 'free':
      default:
        return 1; // 1 minute
    }
  };

  // Helper functions to check user access (using existing membershipInfo for now)
  const isFreeTier = () => !membershipInfo || membershipInfo.membershipTier === 'free';
  const isBasicTier = () => membershipInfo?.membershipTier === 'basic';
  const isPremiumTier = () => membershipInfo?.membershipTier === 'premium';
  const hasBasicAccess = () => isBasicTier() || isPremiumTier();
  const hasPremiumAccess = () => isPremiumTier();
  const canDownload = () => membershipInfo?.canDownload === true;
  
  // Check if user is on trial
  const isOnTrial = () => {
    if (!membershipInfo) return false;
    return membershipInfo.isOnTrial === true;
  };

  // Feature access controls
  const canUploadAudio = () => hasBasicAccess();
  const canRecordAudio = () => hasPremiumAccess();
  const canCreateVideo = () => hasPremiumAccess();
  const canUploadVideo = () => hasPremiumAccess();
  const getMaxAudioDuration = () => {
    if (hasPremiumAccess()) return 120; // 2 hours
    if (hasBasicAccess()) return 30; // 30 minutes
    return 1; // 1 minute for free
  };

  const maxDuration = getMaxDuration();
  const audioSchema = createAudioSchema(maxDuration);
  
  const form = useForm<AudioFormData>({
    resolver: zodResolver(audioSchema),
    defaultValues: {
      affirmations: "",
      preset: "",
      customFrequency: 40,
      volume: 70,
      duration: Math.min(1, maxDuration), // Default to 1 minute or max allowed
      voice: "female",
      uploadedAudio: undefined,
      uploadedVideo: undefined,
      recordedAudio: undefined,
      useUploadedAudio: false,
      useUploadedVideo: false,
      useRecordedAudio: false,
      generateVideoOutput: false,
      generateAudioOutput: true,
      textOverlayEnabled: false,
      textFont: "Arial",
      textFontSize: 24,
      textColor: "#FFFFFF",
      textPosition: "center",
      textOpacity: 0.8,
      textAnimation: "fade",
      showAffirmationsAsText: false,
      createVideoFromScratch: false,
      videoCreationType: "canvas",
      canvasBackground: "#000000",
      videoDuration: Math.min(60, maxDuration * 60), // Default to 1 minute or max allowed
      recordedVideo: undefined,
    },
  });

  const watchedAffirmations = form.watch("affirmations");
  const watchedFrequency = form.watch("customFrequency");

  useEffect(() => {
    setCharacterCount(watchedAffirmations.length);
  }, [watchedAffirmations]);

  // Fetch membership info on component mount (using a mock user ID for now)
  useEffect(() => {
    const fetchMembershipInfo = async () => {
      try {
        const response = await fetch('/api/user/1/membership');
        if (response.ok) {
          const data = await response.json();
          setMembershipInfo(data);
        } else {
          // Set default free tier info if user doesn't exist
          setMembershipInfo({
            membershipTier: 'free',
            downloadsUsed: 0,
            canDownload: false,
            reason: 'Upgrade to Basic or Premium to download audio files'
          });
        }
      } catch (error) {
        console.error('Failed to fetch membership info:', error);
        // Set default free tier info on error
        setMembershipInfo({
          membershipTier: 'free',
          downloadsUsed: 0,
          canDownload: false,
          reason: 'Upgrade to Basic or Premium to download audio files'
        });
      }
    };
    
    fetchMembershipInfo();
  }, []);

  const handlePresetChange = (preset: string) => {
    const presetData = PRESETS.find(p => p.value === preset);
    if (presetData) {
      form.setValue("customFrequency", presetData.frequency);
    }
  };

  const loadSampleAffirmations = () => {
    form.setValue("affirmations", SAMPLE_AFFIRMATIONS.join(". "));
  };

  // Audio recording functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setRecordedBlob(blob);
        form.setValue('recordedAudio', blob);
        form.setValue('useRecordedAudio', true);
        
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
        
        toast({
          title: "Recording Complete",
          description: "Audio recorded successfully.",
        });
      };

      setMediaRecorder(recorder);
      recorder.start();
      setIsRecording(true);
      
      toast({
        title: "Recording Started",
        description: "Speak your affirmations now...",
      });
    } catch (error) {
      console.error('Error starting recording:', error);
      toast({
        title: "Recording Error",
        description: "Could not access microphone.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
      setMediaRecorder(null);
    }
  };

  const clearRecording = () => {
    setRecordedBlob(null);
    form.setValue('recordedAudio', undefined);
    form.setValue('useRecordedAudio', false);
  };

  // Video creation functions
  const startVideoRecording = async (type: 'camera' | 'screen') => {
    try {
      let stream: MediaStream;
      
      if (type === 'camera') {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { width: 1280, height: 720 }, 
          audio: true 
        });
      } else {
        stream = await navigator.mediaDevices.getDisplayMedia({ 
          video: { width: 1280, height: 720 },
          audio: true 
        });
      }
      
      setVideoStream(stream);
      
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      const chunks: Blob[] = [];
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };
      
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        setRecordedVideoBlob(blob);
        form.setValue('recordedVideo', blob);
        stream.getTracks().forEach(track => track.stop());
        setVideoStream(null);
      };
      
      recorder.start();
      setVideoRecorder(recorder);
      setIsVideoRecording(true);
      
      toast({
        title: `${type === 'camera' ? 'Camera' : 'Screen'} recording started`,
        description: "Click stop when you're finished recording",
      });
    } catch (error) {
      toast({
        title: "Recording failed",
        description: error instanceof Error ? error.message : 'Unable to access video',
        variant: "destructive",
      });
    }
  };

  const stopVideoRecording = () => {
    if (videoRecorder && isVideoRecording) {
      videoRecorder.stop();
      setIsVideoRecording(false);
      setVideoRecorder(null);
    }
  };

  const createCanvasVideo = async () => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1280;
      canvas.height = 720;
      const ctx = canvas.getContext('2d')!;
      
      // Set background
      ctx.fillStyle = form.watch('canvasBackground');
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Add text if enabled
      if (form.watch('showAffirmationsAsText') && form.watch('affirmations')) {
        ctx.font = `${form.watch('textFontSize')}px ${form.watch('textFont')}`;
        ctx.fillStyle = form.watch('textColor');
        ctx.globalAlpha = form.watch('textOpacity');
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        const lines = form.watch('affirmations').split('\n');
        const lineHeight = form.watch('textFontSize') * 1.2;
        const startY = canvas.height / 2 - (lines.length - 1) * lineHeight / 2;
        
        lines.forEach((line, index) => {
          ctx.fillText(line, canvas.width / 2, startY + index * lineHeight);
        });
      }
      
      const stream = canvas.captureStream(30);
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
      const chunks: Blob[] = [];
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };
      
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        setGeneratedVideoBlob(blob);
        form.setValue('recordedVideo', blob);
      };
      
      recorder.start();
      setCanvasRecorder(recorder);
      
      // Record for specified duration
      setTimeout(() => {
        recorder.stop();
        setCanvasRecorder(null);
        toast({
          title: "Canvas video created",
          description: "Your custom video has been generated",
        });
      }, form.watch('videoDuration') * 1000);
      
      toast({
        title: "Creating canvas video",
        description: `Generating ${form.watch('videoDuration')} second video...`,
      });
    } catch (error) {
      toast({
        title: "Canvas video creation failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    }
  };

  const clearVideoRecording = () => {
    setRecordedVideoBlob(null);
    form.setValue('recordedVideo', undefined);
    if (videoStream) {
      videoStream.getTracks().forEach(track => track.stop());
      setVideoStream(null);
    }
  };

  const handlePlayPreview = async () => {
    // If we have generated audio, play it; otherwise generate a preview
    if (generatedAudio) {
      playPreview();
    } else {
      const formData = form.getValues();
      
      try {
        const previewBlob = await generatePreview({
          affirmations: formData.affirmations || "Preview test",
          frequency: formData.customFrequency,
          volume: formData.volume,
          duration: 1, // Short preview
          voice: formData.voice,
          preset: formData.preset
        });
        
        // Play the preview blob directly using audioService
        const { audioService } = await import("@/services/audio-service");
        audioService.playPreview(previewBlob);
        
        toast({
          title: "Preview Playing",
          description: "Playing audio preview with affirmations.",
        });
      } catch (error) {
        console.error('Preview generation failed:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        
        toast({
          title: "Preview Failed",
          description: `Preview error: ${errorMessage}`,
          variant: "destructive",
        });
      }
    }
  };

  const handlePreview = async () => {
    const formData = form.getValues();
    
    try {
      const previewBlob = await generatePreview({
        affirmations: formData.affirmations || "Preview test",
        frequency: formData.customFrequency,
        volume: formData.volume,
        duration: 1, // Short preview
        voice: formData.voice,
        preset: formData.preset
      });
      
      // Use audioService to play the preview with affirmations
      const { audioService } = await import("@/services/audio-service");
      audioService.playPreview(previewBlob);
      
      toast({
        title: "Preview Playing",
        description: "5-second binaural beat preview with affirmations is now playing.",
      });
    } catch (error) {
      console.error('Preview generation failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      
      toast({
        title: "Preview Failed",
        description: `Preview error: ${errorMessage}`,
        variant: "destructive",
      });
    }
  };

  const testVoice = async () => {
    const formData = form.getValues();
    const { audioService } = await import("@/services/audio-service");
    
    try {
      await audioService.testVoice(formData.voice);
      toast({
        title: "Voice Test",
        description: `Testing ${formData.voice} voice - you should hear it speak now.`,
      });
    } catch (error) {
      console.error('Voice test failed:', error);
      toast({
        title: "Voice Test Failed",
        description: "Could not test voice. Check console for details.",
        variant: "destructive",
      });
    }
  };

  const handleDownload = async () => {
    if (!membershipInfo?.canDownload) {
      toast({
        title: "Download Not Available",
        description: membershipInfo?.reason || "You cannot download audio files with your current membership.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Record the download in the backend
      const response = await fetch('/api/user/1/download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          audioSessionId: 1 // This would be the actual session ID
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.reason || 'Download failed');
      }

      // Use the existing download audio functionality
      downloadAudio();
      
      // Refresh membership info to update download count
      const membershipResponse = await fetch('/api/user/1/membership');
      if (membershipResponse.ok) {
        const data = await membershipResponse.json();
        setMembershipInfo(data);
      }

      toast({
        title: "Download Started",
        description: "Your audio file is downloading...",
      });
    } catch (error) {
      console.error('Download failed:', error);
      toast({
        title: "Download Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    }
  };

  const handleVideoDownload = async () => {
    if (!membershipInfo?.canDownload) {
      toast({
        title: "Download Not Available",
        description: membershipInfo?.reason || "You cannot download video files with your current membership.",
        variant: "destructive",
      });
      return;
    }

    const videoToDownload = generatedVideoBlob || recordedVideoBlob;
    if (!videoToDownload) {
      toast({
        title: "No Video Available",
        description: "Please create a video first before downloading.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Record the download in the backend
      const response = await fetch('/api/user/1/download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          audioSessionId: 1 // This would be the actual session ID
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.reason || 'Download failed');
      }

      // Download the video
      const url = URL.createObjectURL(videoToDownload);
      const a = document.createElement('a');
      a.href = url;
      a.download = `subliminal-video-${Date.now()}.webm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      // Refresh membership info to update download count
      const membershipResponse = await fetch('/api/user/1/membership');
      if (membershipResponse.ok) {
        const data = await membershipResponse.json();
        setMembershipInfo(data);
      }

      toast({
        title: "Download Started",
        description: "Your video file is downloading...",
      });
    } catch (error) {
      console.error('Video download failed:', error);
      toast({
        title: "Download Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    }
  };

  // Preview audio management functions
  const stopPreviewAudio = () => {
    if (previewAudio) {
      previewAudio.pause();
      previewAudio.currentTime = 0;
      setPreviewAudio(null);
    }
  };

  const playPreviewFile = (file: File | Blob) => {
    stopPreviewAudio(); // Stop any currently playing preview
    const url = URL.createObjectURL(file);
    const audio = new Audio(url);
    audio.play();
    setPreviewAudio(audio);
    
    // Auto cleanup when audio ends
    audio.onended = () => {
      setPreviewAudio(null);
      URL.revokeObjectURL(url);
    };
  };

  const handleGenerateAudio = async (data: AudioFormData) => {
    setIsGenerating(true);
    setGenerationProgress(0);
    
    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setGenerationProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 200);

      await generateAudio({
        affirmations: data.affirmations,
        frequency: data.customFrequency,
        volume: data.volume,
        duration: data.duration,
        voice: data.voice,
        preset: data.preset
      });

      clearInterval(progressInterval);
      setGenerationProgress(100);
      
      toast({
        title: "Audio Generated Successfully",
        description: "Your subliminal audio is ready to download.",
      });
    } catch (error) {
      console.error('Audio generation failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      
      toast({
        title: "Generation Failed",
        description: `Audio generation error: ${errorMessage}`,
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
      setTimeout(() => setGenerationProgress(0), 2000);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleGenerateAudio)} className="space-y-6">
          {/* Affirmations Input */}
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-indigo-500/20 rounded-lg flex items-center justify-center">
                  <Edit className="text-indigo-400 w-4 h-4" />
                </div>
                <h2 className="text-lg font-semibold text-white">Custom Affirmations</h2>
              </div>
              
              <FormField
                control={form.control}
                name="affirmations"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        {...field}
                        className="w-full h-32 bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none"
                        placeholder="Enter your positive affirmations here... (e.g., 'I am confident and successful', 'I attract abundance', 'I am worthy of love')"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <div className="flex items-center justify-between mt-3">
                <span className="text-sm text-gray-400">
                  Characters: <span>{characterCount}</span>
                </span>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={loadSampleAffirmations}
                  className="text-indigo-400 hover:text-indigo-300"
                >
                  <Sparkles className="w-4 h-4 mr-1" />
                  Load Examples
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Audio Settings */}
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-8 h-8 bg-violet-500/20 rounded-lg flex items-center justify-center">
                  <Sliders className="text-violet-400 w-4 h-4" />
                </div>
                <h2 className="text-lg font-semibold text-white">Audio Settings</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Preset Selection */}
                <FormField
                  control={form.control}
                  name="preset"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Binaural Beat Presets</FormLabel>
                      <Select 
                        value={field.value} 
                        onValueChange={(value) => {
                          field.onChange(value);
                          handlePresetChange(value);
                        }}
                      >
                        <FormControl>
                          <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-100">
                            <SelectValue placeholder="Select a preset..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          {PRESETS.map(preset => (
                            <SelectItem key={preset.value} value={preset.value} className="text-gray-100">
                              {preset.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />

                {/* Custom Frequency */}
                <FormField
                  control={form.control}
                  name="customFrequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Custom Frequency (Hz)</FormLabel>
                      <div className="flex space-x-3">
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            max="10000"
                            step="1"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            className="bg-gray-700 border-gray-600 text-gray-100"
                          />
                        </FormControl>
                        <Button
                          type="button"
                          variant="outline"
                          className="bg-violet-500/20 text-violet-400 border-violet-500/20 hover:bg-violet-500/30"
                        >
                          Apply
                        </Button>
                      </div>
                    </FormItem>
                  )}
                />
              </div>

              {/* Audio Upload Section - Basic/Premium */}
              {hasBasicAccess() ? (
                <div className="mt-6 p-4 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                  <h3 className="text-emerald-400 font-medium mb-3 flex items-center">
                    <FileAudio className="w-4 h-4 mr-2" />
                    Upload Your Audio
                  </h3>
                  <FormField
                    control={form.control}
                    name="uploadedAudio"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="space-y-3">
                            <Input
                              type="file"
                              accept="audio/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  field.onChange(file);
                                  form.setValue('useUploadedAudio', true);
                                }
                              }}
                              className="bg-gray-700 border-gray-600 text-gray-100 file:bg-emerald-500/20 file:text-emerald-400 file:border-0 file:rounded file:px-3 file:py-1"
                            />
                            {field.value && (
                              <div className="flex items-center justify-between bg-gray-700/50 p-2 rounded">
                                <span className="text-sm text-gray-300">{field.value.name}</span>
                                <div className="flex items-center gap-2">
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="outline"
                                    onClick={() => field.value && playPreviewFile(field.value)}
                                    className="text-emerald-400 hover:text-emerald-300 border-emerald-500/30"
                                  >
                                    <Play className="w-3 h-3" />
                                  </Button>
                                  {previewAudio && (
                                    <Button
                                      type="button"
                                      size="sm"
                                      variant="outline"
                                      onClick={stopPreviewAudio}
                                      className="text-red-400 hover:text-red-300 border-red-500/30"
                                    >
                                      <StopCircle className="w-3 h-3" />
                                    </Button>
                                  )}
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => {
                                      field.onChange(undefined);
                                      form.setValue('useUploadedAudio', false);
                                    }}
                                    className="text-red-400 hover:text-red-300"
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              ) : (
                <div className="mt-6 p-4 bg-gray-700/50 rounded-lg border border-gray-600">
                  <h3 className="text-gray-400 font-medium mb-3 flex items-center">
                    <FileAudio className="w-4 h-4 mr-2" />
                    Upload Your Audio
                  </h3>
                  <p className="text-sm text-gray-400">
                    Basic or Premium membership required to upload audio files.
                  </p>
                  <Link href="/membership">
                    <Button size="sm" className="mt-3 bg-blue-500 hover:bg-blue-600 text-white">
                      Upgrade Now
                    </Button>
                  </Link>
                </div>
              )}

              {/* Video Upload Section - Premium Only */}
              {hasPremiumAccess() ? (
                <div className="mt-6 p-4 bg-purple-500/10 rounded-lg border border-purple-500/20">
                  <h3 className="text-purple-400 font-medium mb-3 flex items-center">
                    <Video className="w-4 h-4 mr-2" />
                    Upload Your Video (Premium)
                  </h3>
                  <FormField
                    control={form.control}
                    name="uploadedVideo"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="space-y-3">
                            <Input
                              type="file"
                              accept="video/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  field.onChange(file);
                                  form.setValue('useUploadedVideo', true);
                                }
                              }}
                              className="bg-gray-700 border-gray-600 text-gray-100 file:bg-purple-500/20 file:text-purple-400 file:border-0 file:rounded file:px-3 file:py-1"
                            />
                            {field.value && (
                              <div className="flex items-center justify-between bg-gray-700/50 p-2 rounded">
                                <span className="text-sm text-gray-300">{field.value.name}</span>
                                <div className="flex items-center gap-2">
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      if (field.value) {
                                        const url = URL.createObjectURL(field.value);
                                        const video = document.createElement('video');
                                        video.src = url;
                                        video.controls = true;
                                        video.style.maxWidth = '300px';
                                        video.style.maxHeight = '200px';
                                        const dialog = document.createElement('div');
                                        dialog.style.position = 'fixed';
                                        dialog.style.top = '50%';
                                        dialog.style.left = '50%';
                                        dialog.style.transform = 'translate(-50%, -50%)';
                                        dialog.style.background = 'rgba(0,0,0,0.9)';
                                        dialog.style.padding = '20px';
                                        dialog.style.borderRadius = '8px';
                                        dialog.style.zIndex = '9999';
                                        dialog.appendChild(video);
                                        const closeBtn = document.createElement('button');
                                        closeBtn.textContent = '×';
                                        closeBtn.style.position = 'absolute';
                                        closeBtn.style.top = '5px';
                                        closeBtn.style.right = '10px';
                                        closeBtn.style.background = 'none';
                                        closeBtn.style.border = 'none';
                                        closeBtn.style.color = 'white';
                                        closeBtn.style.fontSize = '20px';
                                        closeBtn.style.cursor = 'pointer';
                                        closeBtn.onclick = () => document.body.removeChild(dialog);
                                        dialog.appendChild(closeBtn);
                                        document.body.appendChild(dialog);
                                      }
                                    }}
                                    className="text-purple-400 hover:text-purple-300 border-purple-500/30"
                                  >
                                    <Play className="w-3 h-3" />
                                  </Button>
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => {
                                      field.onChange(undefined);
                                      form.setValue('useUploadedVideo', false);
                                    }}
                                    className="text-red-400 hover:text-red-300"
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              ) : (
                <div className="mt-6 p-4 bg-gray-700/50 rounded-lg border border-gray-600">
                  <h3 className="text-gray-400 font-medium mb-3 flex items-center">
                    <Video className="w-4 h-4 mr-2" />
                    Upload Your Video (Premium)
                  </h3>
                  <p className="text-sm text-gray-400">
                    Premium membership required to upload video files.
                  </p>
                  <Link href="/membership">
                    <Button size="sm" className="mt-3 bg-blue-500 hover:bg-blue-600 text-white">
                      Upgrade to Premium
                    </Button>
                  </Link>
                </div>
              )}

              {/* Audio Recording Section - Premium Only */}
              {hasPremiumAccess() ? (
                <div className="mt-6 p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
                  <h3 className="text-blue-400 font-medium mb-3 flex items-center">
                    <Mic className="w-4 h-4 mr-2" />
                    Record Your Audio (Premium)
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      {!isRecording ? (
                        <Button
                          type="button"
                          onClick={startRecording}
                          className="bg-red-500/20 hover:bg-red-500/30 text-red-400 border-red-500/30"
                          variant="outline"
                        >
                          <Mic className="w-4 h-4 mr-2" />
                          Start Recording
                        </Button>
                      ) : (
                        <Button
                          type="button"
                          onClick={stopRecording}
                          className="bg-red-500 hover:bg-red-600 text-white"
                        >
                          <MicOff className="w-4 h-4 mr-2" />
                          Stop Recording
                        </Button>
                      )}
                      
                      {recordedBlob && (
                        <Button
                          type="button"
                          onClick={clearRecording}
                          variant="outline"
                          size="sm"
                          className="text-gray-400 hover:text-gray-300"
                        >
                          Clear
                        </Button>
                      )}
                    </div>
                    
                    {isRecording && (
                      <div className="flex items-center gap-2 text-red-400">
                        <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                        <span className="text-sm">Recording in progress...</span>
                      </div>
                    )}
                    
                    {recordedBlob && (
                      <div className="flex items-center justify-between bg-gray-700/50 p-2 rounded">
                        <span className="text-sm text-gray-300">Audio recorded successfully</span>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => recordedBlob && playPreviewFile(recordedBlob)}
                          className="text-blue-400 hover:text-blue-300 border-blue-500/30"
                        >
                          <Play className="w-3 h-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="mt-6 p-4 bg-gray-700/50 rounded-lg border border-gray-600">
                  <h3 className="text-gray-400 font-medium mb-3 flex items-center">
                    <Mic className="w-4 h-4 mr-2" />
                    Record Your Audio (Premium)
                  </h3>
                  <p className="text-sm text-gray-400">
                    Premium membership required to record audio directly.
                  </p>
                  <Link href="/membership">
                    <Button size="sm" className="mt-3 bg-blue-500 hover:bg-blue-600 text-white">
                      Upgrade to Premium
                    </Button>
                  </Link>
                </div>
              )}

              {/* Audio Controls & Generation - Moved above Video Editor */}
              <Card className="bg-gradient-to-r from-indigo-500/10 to-violet-500/10 border-indigo-500/20">
                <CardContent className="p-4">
                  <div className="space-y-4">
                    {/* Header */}
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-[#000000]">Audio Control Center</h3>
                      <p className="text-xs text-[#000000]">
                        Preview, generate, and download your subliminal audio
                      </p>
                    </div>

                    {/* Waveform Visualization */}
                    <div className="bg-gray-700 rounded-lg p-3 h-16 flex items-center justify-center border border-gray-600">
                      <div className="flex items-center space-x-1">
                        <div className="w-1 bg-indigo-500 rounded-full h-3 waveform-bar"></div>
                        <div className="w-1 bg-indigo-400 rounded-full h-5 waveform-bar"></div>
                        <div className="w-1 bg-indigo-500 rounded-full h-2 waveform-bar"></div>
                        <div className="w-1 bg-indigo-400 rounded-full h-6 waveform-bar"></div>
                        <div className="w-1 bg-indigo-500 rounded-full h-4 waveform-bar"></div>
                        <div className="w-1 bg-indigo-400 rounded-full h-5 waveform-bar"></div>
                        <div className="w-1 bg-indigo-500 rounded-full h-3 waveform-bar"></div>
                        <div className="w-1 bg-indigo-400 rounded-full h-7 waveform-bar"></div>
                        <div className="w-1 bg-indigo-500 rounded-full h-2 waveform-bar"></div>
                        <div className="w-1 bg-indigo-400 rounded-full h-5 waveform-bar"></div>
                        <div className="w-1 bg-indigo-500 rounded-full h-4 waveform-bar"></div>
                        <div className="w-1 bg-indigo-400 rounded-full h-3 waveform-bar"></div>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    {isGenerating && (
                      <div className="space-y-2">
                        <Progress value={generationProgress} className="w-full" />
                        <p className="text-sm text-gray-400">
                          Generating audio... {generationProgress}%
                        </p>
                      </div>
                    )}

                    {/* Audio Controls */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {/* Preview */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-medium text-gray-300">Preview</h4>
                        <div className="flex items-center gap-2">
                          <Button
                            type="button"
                            onClick={handlePreview}
                            variant="outline"
                            size="sm"
                            className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border-blue-500/30"
                          >
                            <Headphones className="w-4 h-4 mr-2" />
                            Preview (5s)
                          </Button>
                          {isPlaying && (
                            <Button
                              type="button"
                              onClick={stopPreview}
                              variant="outline"
                              size="sm"
                              className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border-red-500/30"
                            >
                              <Square className="w-4 h-4 mr-2" />
                              Stop
                            </Button>
                          )}
                        </div>
                        
                        {/* Audio Progress */}
                        {isPlaying && (
                          <div className="space-y-2">
                            <div className="bg-gray-700 h-2 rounded-full overflow-hidden">
                              <div 
                                className="bg-indigo-500 h-full transition-all duration-300"
                                style={{ width: `${(currentTime / audioDuration) * 100}%` }}
                              />
                            </div>
                            <div className="flex justify-between text-xs text-gray-400">
                              <span>{formatTime(currentTime)}</span>
                              <span>{formatTime(audioDuration)}</span>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Download */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-medium text-gray-300">Generate & Download</h4>
                        <div className="space-y-2">
                          <Button
                            type="submit"
                            disabled={isGenerating || !form.watch('affirmations')}
                            className="w-full bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-600 hover:to-violet-600 disabled:opacity-50"
                          >
                            {isGenerating ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Generating...
                              </>
                            ) : (
                              <>
                                <Music className="w-4 h-4 mr-2" />
                                Generate Audio
                              </>
                            )}
                          </Button>
                          
                          {generatedAudio && (
                            canDownload() ? (
                              <Button
                                type="button"
                                onClick={downloadAudio}
                                variant="outline"
                                className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                              >
                                <Download className="w-4 h-4 mr-2" />
                                Download Audio
                              </Button>
                            ) : (
                              <div className="space-y-2">
                                <Button
                                  type="button"
                                  variant="outline"
                                  className="w-full bg-gray-700/50 text-gray-400 border-gray-600 cursor-not-allowed"
                                  disabled
                                >
                                  <Download className="w-4 h-4 mr-2" />
                                  {isOnTrial() ? "Download Not Available in Trial" : "Download Locked"}
                                </Button>
                                <p className="text-xs text-gray-400 text-center">
                                  {isOnTrial() 
                                    ? "Downloads are not available during trial period. Upgrade to unlock downloads."
                                    : "Basic or Premium membership required for downloads"
                                  }
                                </p>
                                <Link href="/membership">
                                  <Button size="sm" className="w-full bg-blue-500 hover:bg-blue-600 text-white">
                                    {isOnTrial() ? "Upgrade to Unlock Downloads" : "Upgrade Now"}
                                  </Button>
                                </Link>
                              </div>
                            )
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Video Editor Section - Premium Only */}
              {hasPremiumAccess() ? (
                <div className="mt-6 p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-lg border border-purple-500/20">
                  <h3 className="text-purple-400 font-medium mb-3 flex items-center">
                    <Video className="w-4 h-4 mr-2" />
                    Subliminal Video Creator (Premium)
                  </h3>
                  <div className="space-y-4">
                    <div className="bg-gray-700/30 p-3 rounded">
                      <h4 className="text-sm font-medium text-gray-300 mb-2">Output Options:</h4>
                      <div className="space-y-2">
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={form.watch('generateVideoOutput')}
                            onChange={(e) => form.setValue('generateVideoOutput', e.target.checked)}
                            className="rounded bg-gray-600 border-gray-500"
                          />
                          <span className="text-sm text-gray-300">Generate Video (combines all elements)</span>
                        </label>
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={form.watch('generateAudioOutput')}
                            onChange={(e) => form.setValue('generateAudioOutput', e.target.checked)}
                            className="rounded bg-gray-600 border-gray-500"
                          />
                          <span className="text-sm text-gray-300">Generate Audio</span>
                        </label>
                      </div>
                    </div>
                    
                    {form.watch('generateVideoOutput') && (
                      <div className="space-y-4">
                        <div className="bg-gray-700/30 p-3 rounded">
                          <h4 className="text-sm font-medium text-gray-300 mb-2">Video Composition:</h4>
                          <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-2 text-xs text-gray-400">
                              <div className="bg-gray-600/50 p-2 rounded text-center">
                                Background Video
                                {form.watch('uploadedVideo') && <span className="text-emerald-400"> ✓</span>}
                              </div>
                              <div className="bg-gray-600/50 p-2 rounded text-center">
                                Audio Track
                                {(form.watch('uploadedAudio') || form.watch('recordedAudio') || form.watch('affirmations')) && <span className="text-emerald-400"> ✓</span>}
                              </div>
                              <div className="bg-gray-600/50 p-2 rounded text-center">
                                Binaural Beats
                                <span className="text-emerald-400"> ✓</span>
                              </div>
                              <div className="bg-gray-600/50 p-2 rounded text-center">
                                Text Overlay
                                {form.watch('textOverlayEnabled') && <span className="text-emerald-400"> ✓</span>}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Text Overlay Controls */}
                        <div className="bg-gray-700/30 p-4 rounded">
                          <div className="flex items-center space-x-3 mb-4">
                            <input
                              type="checkbox"
                              checked={form.watch('textOverlayEnabled')}
                              onChange={(e) => form.setValue('textOverlayEnabled', e.target.checked)}
                              className="rounded bg-gray-600 border-gray-500"
                            />
                            <h4 className="text-sm font-medium text-purple-300">Text Overlay Settings</h4>
                          </div>

                          {form.watch('textOverlayEnabled') && (
                            <div className="space-y-4">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {/* Show Affirmations as Text */}
                                <div>
                                  <label className="flex items-center space-x-2 mb-2">
                                    <input
                                      type="checkbox"
                                      checked={form.watch('showAffirmationsAsText')}
                                      onChange={(e) => form.setValue('showAffirmationsAsText', e.target.checked)}
                                      className="rounded bg-gray-600 border-gray-500"
                                    />
                                    <span className="text-sm text-gray-300">Show Affirmations as Text</span>
                                  </label>
                                </div>

                                {/* Font Selection */}
                                <div>
                                  <label className="block text-sm text-gray-300 mb-1">Font Family</label>
                                  <select
                                    value={form.watch('textFont')}
                                    onChange={(e) => form.setValue('textFont', e.target.value)}
                                    className="w-full bg-gray-600 border border-gray-500 rounded px-3 py-1 text-sm"
                                  >
                                    <option value="Arial">Arial</option>
                                    <option value="Helvetica">Helvetica</option>
                                    <option value="Times New Roman">Times New Roman</option>
                                    <option value="Georgia">Georgia</option>
                                    <option value="Verdana">Verdana</option>
                                    <option value="Trebuchet MS">Trebuchet MS</option>
                                    <option value="Impact">Impact</option>
                                    <option value="Comic Sans MS">Comic Sans MS</option>
                                    <option value="Courier New">Courier New</option>
                                    <option value="Palatino">Palatino</option>
                                  </select>
                                </div>

                                {/* Font Size */}
                                <div>
                                  <label className="block text-sm text-gray-300 mb-1">Font Size</label>
                                  <input
                                    type="range"
                                    min="12"
                                    max="72"
                                    value={form.watch('textFontSize')}
                                    onChange={(e) => form.setValue('textFontSize', parseInt(e.target.value))}
                                    className="w-full"
                                  />
                                  <span className="text-xs text-gray-400">{form.watch('textFontSize')}px</span>
                                </div>

                                {/* Text Color */}
                                <div>
                                  <label className="block text-sm text-gray-300 mb-1">Text Color</label>
                                  <div className="flex items-center space-x-2">
                                    <input
                                      type="color"
                                      value={form.watch('textColor')}
                                      onChange={(e) => form.setValue('textColor', e.target.value)}
                                      className="w-8 h-8 rounded border border-gray-500"
                                    />
                                    <input
                                      type="text"
                                      value={form.watch('textColor')}
                                      onChange={(e) => form.setValue('textColor', e.target.value)}
                                      className="flex-1 bg-gray-600 border border-gray-500 rounded px-2 py-1 text-sm"
                                      placeholder="#FFFFFF"
                                    />
                                  </div>
                                </div>

                                {/* Text Position */}
                                <div>
                                  <label className="block text-sm text-gray-300 mb-1">Text Position</label>
                                  <select
                                    value={form.watch('textPosition')}
                                    onChange={(e) => form.setValue('textPosition', e.target.value as any)}
                                    className="w-full bg-gray-600 border border-gray-500 rounded px-3 py-1 text-sm"
                                  >
                                    <option value="top">Top Center</option>
                                    <option value="center">Center</option>
                                    <option value="bottom">Bottom Center</option>
                                    <option value="top-left">Top Left</option>
                                    <option value="top-right">Top Right</option>
                                    <option value="bottom-left">Bottom Left</option>
                                    <option value="bottom-right">Bottom Right</option>
                                  </select>
                                </div>

                                {/* Text Opacity */}
                                <div>
                                  <label className="block text-sm text-gray-300 mb-1">Text Opacity</label>
                                  <input
                                    type="range"
                                    min="0"
                                    max="1"
                                    step="0.1"
                                    value={form.watch('textOpacity')}
                                    onChange={(e) => form.setValue('textOpacity', parseFloat(e.target.value))}
                                    className="w-full"
                                  />
                                  <span className="text-xs text-gray-400">{Math.round(form.watch('textOpacity') * 100)}%</span>
                                </div>

                                {/* Text Animation */}
                                <div>
                                  <label className="block text-sm text-gray-300 mb-1">Text Animation</label>
                                  <select
                                    value={form.watch('textAnimation')}
                                    onChange={(e) => form.setValue('textAnimation', e.target.value as any)}
                                    className="w-full bg-gray-600 border border-gray-500 rounded px-3 py-1 text-sm"
                                  >
                                    <option value="none">None</option>
                                    <option value="fade">Fade In/Out</option>
                                    <option value="slide">Slide In</option>
                                    <option value="typewriter">Typewriter Effect</option>
                                  </select>
                                </div>
                              </div>

                              {/* Preview */}
                              {form.watch('showAffirmationsAsText') && form.watch('affirmations') && (
                                <div className="bg-gray-800/50 p-4 rounded border border-purple-500/30">
                                  <h5 className="text-xs text-purple-300 mb-2">Text Preview:</h5>
                                  <div 
                                    className="relative bg-black/50 p-4 rounded min-h-[100px] flex items-center justify-center"
                                    style={{
                                      fontFamily: form.watch('textFont'),
                                      fontSize: form.watch('textFontSize') / 2 + 'px', // Scaled down for preview
                                      color: form.watch('textColor'),
                                      opacity: form.watch('textOpacity'),
                                    }}
                                  >
                                    <span className={`text-center ${
                                      form.watch('textPosition').includes('left') ? 'text-left' :
                                      form.watch('textPosition').includes('right') ? 'text-right' : 'text-center'
                                    }`}>
                                      {form.watch('affirmations').split('\n')[0] || 'Your affirmations will appear here'}
                                    </span>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="text-xs text-gray-400 bg-purple-500/10 p-3 rounded border border-purple-500/20">
                          <strong>Advanced Video Editor:</strong> Combine your background video with subliminal audio and customizable text overlays. Perfect for creating professional meditation videos, affirmation content, or subliminal messaging videos with complete control over text appearance and positioning.
                        </div>
                      </div>
                    )}

                    {/* Video Creation from Scratch - Always visible when video output is enabled */}
                    <div className="bg-gray-700/30 p-4 rounded">
                      <div className="flex items-center space-x-3 mb-4">
                        <input
                          type="checkbox"
                          checked={form.watch('createVideoFromScratch')}
                          onChange={(e) => form.setValue('createVideoFromScratch', e.target.checked)}
                          className="rounded bg-gray-600 border-gray-500"
                        />
                        <h4 className="text-sm font-medium text-purple-300">Video Studio (Pro Creator)</h4>
                      </div>

                      {form.watch('createVideoFromScratch') && (
                        <div className="space-y-6">
                          {/* Video Studio Header */}
                          <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 p-4 rounded-lg border border-purple-500/20">
                            <div className="flex items-center gap-3 mb-3">
                              <Clapperboard className="w-6 h-6 text-purple-400" />
                              <h4 className="text-lg font-medium text-white">Professional Video Creator</h4>
                              <span className="px-2 py-1 bg-purple-500/20 text-purple-300 text-xs rounded">PREMIUM</span>
                            </div>
                            <p className="text-sm text-gray-300">
                              Create professional videos for social media, streaming platforms, or personal use with subliminal audio integration
                              {maxDuration >= 120 && (
                                <span className="block mt-1 text-purple-300 font-medium">
                                  ✓ Create videos up to 2 hours long • ✓ Unlimited downloads • ✓ All creation methods
                                </span>
                              )}
                            </p>
                          </div>



                          {/* Movie Maker Style Studio */}
                          {form.watch('videoCreationType') === 'canvas' && (
                            <div className="space-y-4 p-4 bg-gradient-to-br from-purple-500/5 to-blue-500/5 rounded-lg border border-purple-500/20">
                              <div className="flex items-center gap-3 mb-4">
                                <Settings className="w-5 h-5 text-purple-400" />
                                <h5 className="text-lg font-medium text-white">Video Studio - Meditation/Affirmation Template</h5>
                              </div>
                              
                              {/* Timeline Style Controls */}
                              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {/* Left Panel - Video Settings */}
                                <div className="space-y-4">
                                  <div className="bg-gray-800/50 p-4 rounded-lg">
                                    <h6 className="text-sm font-medium text-gray-300 mb-3 flex items-center">
                                      <Film className="w-4 h-4 mr-2" />
                                      Video Properties
                                    </h6>
                                    <div className="space-y-3">
                                      <div>
                                        <label className="block text-sm text-gray-300 mb-2">
                                          Duration 
                                          {maxDuration >= 120 && (
                                            <span className="ml-2 text-purple-300 text-xs">
                                              (Up to 2 hours for Premium - Max: {maxDuration * 60}s)
                                            </span>
                                          )}
                                        </label>
                                        <div className="flex items-center gap-3">
                                          <input
                                            type="range"
                                            min="10"
                                            max={7200} // Hardcoded 2 hours for Premium users
                                            value={form.watch('videoDuration')}
                                            onChange={(e) => form.setValue('videoDuration', parseInt(e.target.value))}
                                            className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                                          />
                                          <div className="bg-gray-700 px-3 py-1 rounded text-sm min-w-[80px] text-center">
                                            {Math.floor(form.watch('videoDuration') / 60)}:{(form.watch('videoDuration') % 60).toString().padStart(2, '0')}
                                          </div>
                                        </div>
                                        <div className="text-xs text-gray-400 mt-1">
                                          {form.watch('videoDuration')} seconds total 
                                          {form.watch('videoDuration') >= 3600 && (
                                            <span className="ml-2 text-purple-300">
                                              ({Math.floor(form.watch('videoDuration') / 3600)}h {Math.floor((form.watch('videoDuration') % 3600) / 60)}m)
                                            </span>
                                          )}
                                        </div>
                                      </div>
                                      
                                      <div>
                                        <label className="block text-sm text-gray-300 mb-2">Background Theme</label>
                                        <div className="grid grid-cols-4 gap-2">
                                          {[
                                            { color: '#000000', name: 'Black' },
                                            { color: '#1a1a2e', name: 'Deep Blue' },
                                            { color: '#16213e', name: 'Navy' },
                                            { color: '#0f3460', name: 'Ocean' },
                                            { color: '#533483', name: 'Purple' },
                                            { color: '#2d1b69', name: 'Violet' },
                                            { color: '#134e5e', name: 'Teal' },
                                            { color: '#71b280', name: 'Forest' }
                                          ].map((theme) => (
                                            <div
                                              key={theme.color}
                                              className={`w-full h-8 rounded cursor-pointer border-2 transition-all ${
                                                form.watch('canvasBackground') === theme.color 
                                                  ? 'border-purple-400 scale-105' 
                                                  : 'border-gray-600 hover:border-gray-500'
                                              }`}
                                              style={{ backgroundColor: theme.color }}
                                              onClick={() => form.setValue('canvasBackground', theme.color)}
                                              title={theme.name}
                                            />
                                          ))}
                                        </div>
                                        <input
                                          type="text"
                                          value={form.watch('canvasBackground')}
                                          onChange={(e) => form.setValue('canvasBackground', e.target.value)}
                                          className="w-full mt-2 bg-gray-700 border border-gray-600 rounded px-3 py-1 text-sm"
                                          placeholder="Custom color (e.g., #000000)"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                {/* Right Panel - Preview */}
                                <div className="space-y-4">
                                  <div className="bg-gray-800/50 p-4 rounded-lg">
                                    <h6 className="text-sm font-medium text-gray-300 mb-3">Preview</h6>
                                    <div 
                                      className="w-full aspect-video rounded-lg border border-gray-600 flex items-center justify-center relative overflow-hidden"
                                      style={{ backgroundColor: form.watch('canvasBackground') }}
                                    >
                                      {form.watch('showAffirmationsAsText') && form.watch('affirmations') ? (
                                        <div 
                                          className="text-center px-4"
                                          style={{
                                            fontFamily: form.watch('textFont'),
                                            fontSize: Math.max(12, form.watch('textFontSize') / 3) + 'px',
                                            color: form.watch('textColor'),
                                            opacity: form.watch('textOpacity'),
                                          }}
                                        >
                                          {form.watch('affirmations').split('\n')[0]}
                                        </div>
                                      ) : (
                                        <div className="text-gray-500 text-sm">
                                          <Video className="w-8 h-8 mx-auto mb-2" />
                                          Enable text overlay to see preview
                                        </div>
                                      )}
                                    </div>
                                  </div>

                                  <div className="space-y-3">
                                    <Button
                                      type="button"
                                      onClick={createCanvasVideo}
                                      disabled={canvasRecorder !== null}
                                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3 text-lg font-medium"
                                    >
                                      {canvasRecorder ? (
                                        <>
                                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                                          Creating Video...
                                        </>
                                      ) : (
                                        <>
                                          <Play className="w-5 h-5 mr-2" />
                                          Create Professional Video
                                        </>
                                      )}
                                    </Button>
                                    
                                    {generatedVideoBlob && (
                                      <Button
                                        type="button"
                                        onClick={handleVideoDownload}
                                        className="w-full bg-green-600 hover:bg-green-700 text-white py-2"
                                      >
                                        <Download className="w-4 h-4 mr-2" />
                                        Download Video ({Math.round(generatedVideoBlob.size / 1024 / 1024 * 100) / 100} MB)
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Camera/Screen Recording Studio */}
                          {(form.watch('videoCreationType') === 'camera' || form.watch('videoCreationType') === 'screen') && (
                            <div className="space-y-4 p-4 bg-gradient-to-br from-blue-500/5 to-green-500/5 rounded-lg border border-blue-500/20">
                              <div className="flex items-center gap-3">
                                {form.watch('videoCreationType') === 'camera' ? (
                                  <>
                                    <Camera className="w-5 h-5 text-blue-400" />
                                    <h5 className="text-lg font-medium text-white">Camera Studio - Personal Recording</h5>
                                  </>
                                ) : (
                                  <>
                                    <Monitor className="w-5 h-5 text-green-400" />
                                    <h5 className="text-lg font-medium text-white">Screen Studio - Tutorial Recording</h5>
                                  </>
                                )}
                              </div>
                              
                              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {/* Recording Controls */}
                                <div className="space-y-4">
                                  <div className="bg-gray-800/50 p-4 rounded-lg">
                                    <h6 className="text-sm font-medium text-gray-300 mb-3">Recording Controls</h6>
                                    <div className="space-y-3">
                                      {!isVideoRecording ? (
                                        <Button
                                          type="button"
                                          onClick={() => startVideoRecording(form.watch('videoCreationType') as 'camera' | 'screen')}
                                          className="w-full bg-red-600 hover:bg-red-700 text-white py-3 text-lg font-medium"
                                        >
                                          <div className="w-4 h-4 bg-white rounded-full mr-3" />
                                          Start {form.watch('videoCreationType') === 'camera' ? 'Camera' : 'Screen'} Recording
                                        </Button>
                                      ) : (
                                        <Button
                                          type="button"
                                          onClick={stopVideoRecording}
                                          className="w-full bg-gray-800 hover:bg-gray-900 text-white py-3 text-lg font-medium border-2 border-red-500"
                                        >
                                          <Square className="w-4 h-4 mr-3" />
                                          Stop Recording
                                        </Button>
                                      )}
                                      
                                      {recordedVideoBlob && (
                                        <div className="space-y-2">
                                          <div className="flex gap-2">
                                            <Button
                                              type="button"
                                              onClick={() => {
                                                if (recordedVideoBlob) {
                                                  const url = URL.createObjectURL(recordedVideoBlob);
                                                  window.open(url, '_blank');
                                                }
                                              }}
                                              className="flex-1 bg-blue-600 hover:bg-blue-700"
                                            >
                                              <Play className="w-4 h-4 mr-2" />
                                              Preview
                                            </Button>
                                            <Button
                                              type="button"
                                              onClick={clearVideoRecording}
                                              variant="outline"
                                              className="px-4"
                                            >
                                              <X className="w-4 h-4" />
                                            </Button>
                                          </div>
                                          <Button
                                            type="button"
                                            onClick={handleVideoDownload}
                                            className="w-full bg-green-600 hover:bg-green-700 text-white"
                                          >
                                            <Download className="w-4 h-4 mr-2" />
                                            Download Video ({Math.round(recordedVideoBlob.size / 1024 / 1024 * 100) / 100} MB)
                                          </Button>
                                        </div>
                                      )}
                                    </div>
                                  </div>

                                  {form.watch('videoCreationType') === 'camera' && (
                                    <div className="bg-blue-500/10 p-3 rounded border border-blue-500/20">
                                      <h6 className="text-blue-300 font-medium mb-2">Camera Tips</h6>
                                      <ul className="text-xs text-gray-400 space-y-1">
                                        <li>• Ensure good lighting for best results</li>
                                        <li>• Position camera at eye level</li>
                                        <li>• Test audio before recording</li>
                                        <li>• Perfect for talking head content</li>
                                      </ul>
                                    </div>
                                  )}

                                  {form.watch('videoCreationType') === 'screen' && (
                                    <div className="bg-green-500/10 p-3 rounded border border-green-500/20">
                                      <h6 className="text-green-300 font-medium mb-2">Screen Recording Tips</h6>
                                      <ul className="text-xs text-gray-400 space-y-1">
                                        <li>• Close unnecessary applications</li>
                                        <li>• Select specific window or full screen</li>
                                        <li>• System audio will be included</li>
                                        <li>• Great for tutorials and demos</li>
                                      </ul>
                                    </div>
                                  )}
                                </div>

                                {/* Status Panel */}
                                <div className="space-y-4">
                                  {isVideoRecording && (
                                    <div className="bg-red-500/10 p-4 rounded-lg border border-red-500/30">
                                      <div className="flex items-center gap-3 mb-3">
                                        <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                                        <span className="text-red-300 font-medium">LIVE RECORDING</span>
                                      </div>
                                      <div className="text-sm text-gray-300">
                                        Recording {form.watch('videoCreationType') === 'camera' ? 'camera feed' : 'screen activity'} in progress...
                                      </div>
                                    </div>
                                  )}
                                  
                                  {recordedVideoBlob && (
                                    <div className="bg-green-500/10 p-4 rounded-lg border border-green-500/30">
                                      <div className="flex items-center gap-3 mb-2">
                                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                                        <span className="text-green-300 font-medium">Recording Complete</span>
                                      </div>
                                      <div className="text-sm text-gray-300 mb-3">
                                        Your {form.watch('videoCreationType')} video is ready to use
                                      </div>
                                      <div className="bg-gray-800/50 p-3 rounded">
                                        <div className="text-xs text-gray-400">
                                          <div>• Quality: HD (1280x720)</div>
                                          <div>• Format: WebM</div>
                                          <div>• Audio: Included</div>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {!isVideoRecording && !recordedVideoBlob && (
                                    <div className="bg-gray-800/30 p-4 rounded-lg border border-gray-600/30">
                                      <h6 className="text-gray-300 font-medium mb-3">Ready to Record</h6>
                                      <div className="text-sm text-gray-400">
                                        Click the red record button to start capturing your {form.watch('videoCreationType')} content
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          )}

                          <div className="text-xs text-gray-400 bg-purple-500/10 p-2 rounded border border-purple-500/20">
                            <strong>Create from Scratch:</strong> Generate videos using canvas graphics, record with your camera, or capture your screen. Perfect for creating custom backgrounds, instructional content, or personalized meditation videos.
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="mt-6 p-4 bg-gray-700/50 rounded-lg border border-gray-600">
                  <h3 className="text-gray-400 font-medium mb-3 flex items-center">
                    <Video className="w-4 h-4 mr-2" />
                    Subliminal Video Creator (Premium Only)
                  </h3>
                  <p className="text-sm text-gray-400 mb-3">
                    Create professional videos with subliminal audio integration. Premium membership required.
                  </p>
                  <ul className="text-sm text-gray-500 mb-4 space-y-1">
                    <li>• 2-hour video duration</li>
                    <li>• Camera & screen recording</li>
                    <li>• Custom video backgrounds</li>
                    <li>• Text overlays & animations</li>
                    <li>• Professional video export</li>
                  </ul>
                  <Link href="/membership">
                    <Button size="sm" className="bg-purple-500 hover:bg-purple-600 text-white">
                      Upgrade to Premium
                    </Button>
                  </Link>
                </div>
              )}

              {/* Frequency Slider */}
              <div className="mt-6 space-y-3">
                <div className="flex items-center justify-between">
                  <FormLabel className="text-gray-300">Frequency Slider</FormLabel>
                  <span className="text-sm text-violet-400 font-mono">
                    {watchedFrequency.toFixed(1)} Hz
                  </span>
                </div>
                <FormField
                  control={form.control}
                  name="customFrequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Slider
                          min={1}
                          max={10000}
                          step={1}
                          value={[field.value]}
                          onValueChange={(value) => field.onChange(value[0])}
                          className="frequency-slider"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>1Hz</span>
                  <span>100Hz</span>
                  <span>1kHz</span>
                  <span>5kHz</span>
                  <span>10kHz</span>
                </div>
              </div>

              {/* Additional Settings */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <FormField
                  control={form.control}
                  name="volume"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Volume</FormLabel>
                      <FormControl>
                        <Slider
                          min={0}
                          max={100}
                          step={1}
                          value={[field.value]}
                          onValueChange={(value) => field.onChange(value[0])}
                          className="volume-slider"
                        />
                      </FormControl>
                      <span className="text-xs text-gray-400">{field.value}%</span>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => {
                    const maxDuration = getMaxDuration();
                    const tierName = membershipInfo?.membershipTier === 'premium' ? 'Premium' : 
                                   membershipInfo?.membershipTier === 'basic' ? 'Basic' : 'Free';
                    
                    return (
                      <FormItem>
                        <FormLabel className="text-gray-300">
                          Duration (min) 
                          <span className="text-xs text-gray-400 ml-2">
                            {tierName}: max {maxDuration === 120 ? '2 hours' : `${maxDuration} min`}
                          </span>
                        </FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="1"
                            max={maxDuration}
                            {...field}
                            onChange={(e) => {
                              const value = parseInt(e.target.value);
                              if (value > maxDuration) {
                                field.onChange(maxDuration);
                              } else {
                                field.onChange(value);
                              }
                            }}
                            className="bg-gray-700 border-gray-600 text-gray-100"
                          />
                        </FormControl>
                        {field.value > maxDuration && (
                          <div className="text-xs text-amber-400 bg-amber-500/10 p-2 rounded border border-amber-500/20 mt-1">
                            Duration limited to {maxDuration === 120 ? '2 hours' : `${maxDuration} minutes`} for {tierName} plan
                          </div>
                        )}
                      </FormItem>
                    );
                  }}
                />

                <FormField
                  control={form.control}
                  name="voice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Voice</FormLabel>
                      <div className="flex items-center gap-2">
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-100">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-gray-700 border-gray-600">
                            <SelectItem value="female" className="text-gray-100">Female</SelectItem>
                            <SelectItem value="male" className="text-gray-100">Male</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          type="button"
                          onClick={testVoice}
                          variant="outline"
                          size="sm"
                          className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border-blue-500/30"
                        >
                          Test Voice
                        </Button>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>
        </form>
      </Form>
    </div>
  );
}
